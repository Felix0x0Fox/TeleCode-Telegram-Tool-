ВЗЯТО С КАНАЛА - @thiasoft
ПРОСЬБА ОСТАВЛЯТЬ ИСТОЧНИКИ!

Код писал - @Xahrvs
Github - https://github.com/Felix0x0Fox